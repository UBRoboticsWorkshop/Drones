#ifndef DroneMathsRB_h
#define DroneMathsRB_h 

#define MAX_MATRIX_SIZE 6

#include <Arduino.h>
#include <vector>

class quaternion{
  public:
    quaternion();
    quaternion(float w,float x,float y,float z);
    float theta = 1;
    float vector[3] = { 0, 0, 0 }; //Why isn't this a vector class? Becuase I added quaternions before vectors, and if you're reading this I'm too lazy to refactor it. Upgrade to UBRobotics premium and I'll do it
    quaternion operator* (quaternion q2);
    quaternion operator* (float postMult);
    quaternion operator+ (quaternion qIn2);

};

class vector{
  public:
  //vector();
  //vector(float x, float y, float z);
  float x=0,y=0,z=0;
  vector operator* (float postMult);
  vector operator/ (float postMult);
  vector elementwiseMultiplication(vector vin);
  vector operator+ (vector vIn);
  vector operator- (vector vIn);
  vector operator& (vector vin);
  float operator* (vector vIn);
  void operator= (float vin[3]);
  vector operator+ (float vin[3]);
  vector operator+= (vector vin);
  float magnitude();
  float magnitudeNoSqr();
};

//Returns the conjugate, an equal and opposite quaternion
class quaternion conj(quaternion qIn);

//Returns a unit quaternion
class quaternion qNormalize(quaternion qIn);

//Returns a quaternion q_t+1 assuming angular velocity vin, timestep milliseconds into the future
class quaternion applyW(quaternion qIn, class vector vin, float timestep);

//Returns the product of two quaternions without normalizing the result (this is the "true" form of the quaternion product, but can cause accumulating errors)
class quaternion HPNN(quaternion q1, quaternion q2);

//Returns the magnitude of qIn
float qMagnitude(quaternion qIn);

//Returns a vector which is vin rotated by qin
class vector rotateVector(class vector vin, quaternion qIn); 


//returns in radians the angle between 2 vectors
float vectorAngleBetween(vector vin1, vector vin2);

//Returns the unit vecot of vin
class vector normalize(vector vin);

//Makes a quaternion in which theta = 0, the vector part is vin
quaternion vectorToQ(vector vin);

//Prints a quaternion in a way that's easy to read over serial
void printQuat(quaternion q1, String tag);

//Same as above but vectors
void printVec(vector vec, String tag);

//Returns a quaternion from a vector and an angle
quaternion qFromAxisAngle(vector vin, float angle);

#endif