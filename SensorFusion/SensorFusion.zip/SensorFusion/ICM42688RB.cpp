#include "esp32-hal-gpio.h"
#include <Arduino.h>
#include <SPI.h>
#include "DroneMathsRB.h"
#include "ICM42688RB.h"

IMU::IMU(int _bus, int _miso, int _mosi, int _clk, int _ncs) {
  bus = _bus;
  ncs = _ncs;
  IMUSPI = new SPIClass(bus);
  pinMode(ncs, OUTPUT);
  digitalWrite(ncs, HIGH);
  //IMUSPI->begin(14,12,26,27);  //Setup SPI, the ICM42688 can tolerate 24MHz for all registers, but we'll set it to 20MHz
  IMUSPI->begin(_clk, _miso, _mosi, 47);
  IMUSPI->setFrequency(20000000);
  IMUSPI->setDataMode(SPI_MODE0);
  IMUSPI->setBitOrder(MSBFIRST);
}


bool IMU::initalize() {
  if (readIMURegister(117) == ICM42688_ID) {
    writeIMUSPI(B0_DEVICE_CONFIG, 0x01);  //Reset device
    delay(100);
    writeIMUSPI(B0_GYRO_CONFIG0, 0b00000100);  //Scale to 2000DPS, output data rate (ODR) 4KHz
    writeIMUSPI(B0_ACC_CONFIG0, 0b01000101);   //Scale to 4g, 2KHz ODR
    writeIMUSPI(B0_GYRO_CONFIG1, 0b00111010);  //Gyro bandwidth at 170Hz, 2nd order filter
    //writeIMUSPI(B0_ACC_CONFIG1, 0b00010000);  //Acc bandwidth at 170Hz, 2nd order filter

    delay(10);
    writeIMUSPI(B0_POWER_MANAGEMENT0, 0x0F);  //Turn on acc and gyro in low noise mode (Strangely there's no high noise mode. Lacking essential feature here, Invensense)
    delay(100);

    Serial.println("IMU active");
    return true;
  } else {
    Serial.println("IMU not detected! Flying without the IMU will void your warranty, and your membership will not be refunded!");
    Serial.println("No but really something has gone horribly wrong. Please speak to me about this");
    Serial.println(readIMURegister(117));
    return false;
  }
}


void IMU::setZeroAngle(quaternion zeroAngle) {
  Serial.println("TODO:IMPLEMENT THIS FUNCTION");
}

void IMU::read(inertialDataPacket_t &data) {
  int16_t LAX;
  int16_t LAY;
  int16_t LAZ;

  int16_t AVX;
  int16_t AVY;
  int16_t AVZ;

  byte rawData[12] = {0};
  data.timestamp = micros();

  readIMUSPI(ACC_X_H, 12, rawData);

  LAX = rawData[0] << 8 | rawData[1];
  LAY = rawData[2] << 8 | rawData[3];
  LAZ = rawData[4] << 8 | rawData[5];

  AVX = rawData[6] << 8 | rawData[7];
  AVY = rawData[8] << 8 | rawData[9];
  AVZ = rawData[10] << 8 | rawData[11];


  data.xG = -(float)LAX * ACC_SCALE / ICM42688_RESOLUTION;
  data.yG = (float)LAY * ACC_SCALE / ICM42688_RESOLUTION;
  data.zG = -(float)LAZ * ACC_SCALE / ICM42688_RESOLUTION;

  data.xRads = -(float)(PI/180) * AVX * GYRO_SCALE / ICM42688_RESOLUTION;
  data.yRads = (float)(PI/180) * AVY * GYRO_SCALE / ICM42688_RESOLUTION;
  data.zRads = -(float)(PI/180) * AVZ * GYRO_SCALE / ICM42688_RESOLUTION;
}

bool IMU::calibrateGyro(float targetVariance, int calibrationSamples) {
  float variance;  //So technically this isn't actually variance, but it doesn't really matter in practice
  inertialDataPacket_t calData;

  float sumX=0;
  float sumY=0;
  float sumZ=0;

  float sumSquaresX=0;
  float sumSquaresY=0;
  float sumSquaresZ=0;

  for (int i = 0; i < calibrationSamples; i++) {
    read(calData);
    sumX += calData.xRads/(PI/180);
    sumY += calData.yRads/(PI/180);
    sumZ += calData.zRads/(PI/180);

    sumSquaresX += calData.xRads/(PI/180) * calData.xRads/(PI/180);
    sumSquaresY += calData.yRads/(PI/180) * calData.yRads/(PI/180);
    sumSquaresZ += calData.zRads/(PI/180) * calData.zRads/(PI/180);
  }

  float avgX = sumX / calibrationSamples;
  float avgY = sumY / calibrationSamples;
  float avgZ = sumZ / calibrationSamples;

  float varX = (sumSquaresX / calibrationSamples) - (avgX * avgX);
  float varY = (sumSquaresY / calibrationSamples) - (avgY * avgY);
  float varZ = (sumSquaresZ / calibrationSamples) - (avgZ * avgZ);

  Serial.println(varX,50);
  Serial.println(targetVariance,50);

  if (varX < targetVariance && varY < targetVariance && varZ < targetVariance) {
    //Making sense so far? HAHAHAHHAHAHAHHAHAHAH WATCH THIS
    int16_t driftCorrectionX = 32 * 16 * avgX;
    int16_t driftCorrectionY = -32 * 16 * avgY;
    int16_t driftCorrectionZ = 32 * 16 * avgZ;

    driftCorrectionX = driftCorrectionX >> 4;
    driftCorrectionY = driftCorrectionY >> 4;
    driftCorrectionZ = driftCorrectionZ >> 4;
    //driftCorrectionZ-=2;

    uint8_t HBDCX = (uint8_t)(driftCorrectionX >> 8) & 0x0F;
    uint8_t LBDCX = (uint8_t)(driftCorrectionX &  0xFF);
    uint8_t HBDCY = (uint8_t)(driftCorrectionY >> 8) & 0x0F;
    uint8_t LBDCY = (uint8_t)(driftCorrectionY &  0xFF);
    uint8_t HBDCZ = (uint8_t)(driftCorrectionZ >> 8) & 0x0F;
    uint8_t LBDCZ = (uint8_t)(driftCorrectionZ &  0xFF);

    uint8_t OFFSET_USER0_TEMP = LBDCX;
    uint8_t OFFSET_USER1_TEMP = (HBDCY<<4)|(HBDCX);
    uint8_t OFFSET_USER2_TEMP = LBDCY;
    uint8_t OFFSET_USER3_TEMP = LBDCZ;
    uint8_t OFFSET_USER4_TEMP = HBDCZ;


    writeIMUSPI(B0_DEVICE_CONFIG, 0x01);  //Reset device
    delay(100);    
    writeIMUSPI(B0_GYRO_CONFIG0, 0b00000100);  //Scale to 2000DPS, output data rate (ODR) 4KHz
    writeIMUSPI(B0_ACC_CONFIG0, 0b01000101);   //Scale to 4g, 2KHz ODR
    writeIMUSPI(B0_GYRO_CONFIG1, 0b00111010);  //Gyro bandwidth at 170Hz, 2nd order filter

    writeIMUSPI(REG_BANK_SEL, 4);

    writeIMUSPI(OFFSET_USER0,  OFFSET_USER0_TEMP);
    writeIMUSPI(OFFSET_USER1,  OFFSET_USER1_TEMP);
    writeIMUSPI(OFFSET_USER2,  OFFSET_USER2_TEMP);
    writeIMUSPI(OFFSET_USER3,  OFFSET_USER3_TEMP);
    writeIMUSPI(OFFSET_USER4,  OFFSET_USER4_TEMP);

    writeIMUSPI(REG_BANK_SEL, 0);


    delay(10);
    writeIMUSPI(B0_POWER_MANAGEMENT0, 0x0F);  //Turn on acc and gyro in low noise mode (Strangely there's no high noise mode. Lacking essential feature here, Invensense)
    delay(100);

    return true;
  }
  Serial.println("Large gyroscope variance detected, please ensure UAV is stable");
  return false;
}

int IMU::readIMURegister(int reg) {
  int regData;  //Effectively the same as readSPI, except it only reads one register and returns it for ease of use

  digitalWrite(ncs, LOW);

  IMUSPI->transfer(reg + 0x80);
  regData = IMUSPI->transfer(0x00);

  digitalWrite(ncs, HIGH);

  return regData;
}

void IMU::writeIMUSPI(int reg, int value) {
  digitalWrite(ncs, LOW);  //Pull CS line for the ICM42688 low, beginning the transmittion

  IMUSPI->transfer(reg);  //Send register address

  IMUSPI->transfer(value);  //Send new value

  digitalWrite(ncs, HIGH);  //End the transmittion by pulling the line high again


  delayMicroseconds(1);  //delay required to prevent overlapping commands
}

void IMU::readIMUSPI(int reg, int count, byte data[]) {
  digitalWrite(ncs, LOW);  //Pull CS line for the ICM42688 low, beginning the transmittion

  IMUSPI->transfer(reg + 0x80);  //Send the address for the first register to read, with the read bit set high (hence the + 0x80)

  IMUSPI->transferBytes(data, data, 12);

  digitalWrite(ncs, HIGH);  //End the transmittion by pulling the line high again
  IMUSPI->endTransaction();
}