#ifndef ICM42688RB_h
#define ICM42688RB_h 

#include <Arduino.h> 
#include <SPI.h>
#include "DroneMathsRB.h"

#define GYRO_SCALE 2000
#define ACC_SCALE 4
#define ICM42688_RESOLUTION 32768
#define ICM42688_ID 71

//Bank select
#define REG_BANK_SEL 0x76

//Useful registers: Bank 0
#define B0_DEVICE_CONFIG 0x11 //Write 0x01 to reset device, bit 4 sets SPI mode (keep as 0)

#define B0_DRIVE_CONFIG 0x13 //Used to set how fast SPI signals turn on and off, keep as default

#define B0_TEMP_DATA_H 0x1D //IMU integrated thermometer
#define B0_TEMP_DATA_L 0x1E

#define ACC_X_H 0x1F //Here is the latest data from the IMU
#define ACC_X_L 0x20
#define ACC_Y_H 0x21
#define ACC_Y_L 0x22
#define ACC_Z_H 0x23
#define ACC_Z_L 0x24

#define GYRO_X_H 0x25
#define GYRO_X_L 0x26
#define GYRO_Y_H 0x27
#define GYRO_Y_L 0x28
#define GYRO_Z_H 0x29
#define GYRO_Z_L 0x2A

#define WHO_AM_I 0x75 //This register contains the device ID, so we can check that the device is connected. Should always be 0x47.

#define B0_POWER_MANAGEMENT0 0x4E //Needed to turn the sensors on. Turn this on AFTER config is done
#define B0_GYRO_CONFIG0 0x4F //Used to set full scale and data rate for gyro
#define B0_ACC_CONFIG0 0x50 //Same as above, for acc
#define B0_GYRO_CONFIG1 0x51 //Used to setup the digital lowpass filter (LPF) for the gyro
#define B0_GYRO_ACC_CONFIG0 0x52 //Sets decimation and LPFs
#define B0_ACC_CONFIG1 0x53 //Sets order of acc filter

#define OFFSET_USER0 0x77
#define OFFSET_USER1 0x78
#define OFFSET_USER2 0x79
#define OFFSET_USER3 0x7A
#define OFFSET_USER4 0x7B

//Useful registers: Bank 1
#define B1_INTF_CONFIG6 0x7C //Both of these should be kept as default for SPI operation
#define B1_INTF_CONFIG4 0x7A

//A structure that holds filtered and scaled data from the IMU
struct inertialDataPacket_t{ 
  float xRads; //angular velocity in radians per second
  float yRads;
  float zRads;
  
  float xG; //Measured acceleration in G
  float yG;
  float zG;

  unsigned long timestamp; //value of micros() when taken. This value will overflow very quickly- all functions using this must be made to account for this. For sensor fusion, this will happen automatically.
};

class IMU{
  private:
  SPIClass * IMUSPI = NULL;
  int bus, ncs;
  quaternion mountingAngle;

  public:
  /*
  @Bus 
  Will select which SPI controller is used, FSPI or HSPI. Doesn't really matter, unless you have an SPI device on the GPIO running on the second core. In this case, use different busses.
  @ _miso, _mosi, _clk, _ncs
  Pins for the IMU. Should be 17,15,16,18 on the air unit V2.
  */  
  IMU(int _bus, int _miso, int _mosi, int _clk, int _ncs);

  /*
  
  */
  void read(inertialDataPacket_t &data);

  /*
    Turns on the IMU, and sets filtering/scale. Don't modify the IMU settings after calling this without turning off the sensors.
    Blocking function, since the ICM takes some time to boot up
  */
  bool initalize();

  /*
    Compensates for the air unit being mounted in a non-standard orientation
    @zeroAngle describes the angle of the IMU when the airframe is at (1,0,0,0)
  */
  void setZeroAngle(quaternion zeroAngle);

  /*
    Finds the average gyro bias, and sets internal compensation accordingly if the variance is acceptable
    @targetVariance maximum deviation from steady signal, to detect if the craft is moved during calibration
    @calibrationSamples number of samples to read
  */
  bool calibrateGyro(float targetVariance, int calibrationSamples);

  /*
  Reads a set of consecutive registers. Much faster than reading them one by one
  @reg the first register to read
  @count the number of registers to read
  @data an array of bytes to store all that lovely data. Make sure this is at least as long as count, or get vapourized 
  */
  void readIMUSPI(int reg, int count, byte data[]);

  /*
  Sets the value of one register in the IMU
  @reg the register to write to
  @value the value to set it to
  */
  void writeIMUSPI(int reg, int value);

  /*
  Reads a single register from the IMU
  @reg the register to read
  */
  int readIMURegister(int reg);

};

#endif