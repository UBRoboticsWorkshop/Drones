#include "Arduino.h"
#include "CommsRB.h"
#include <WiFi.h>
#include <esp_now.h>

droneStatus_t statusIn;
cycleCommand_t commandOut;
esp_now_peer_info_t peerInfo;
unsigned long lastValidSignal;
bool newData;

void getTransmittedData(const esp_now_recv_info_t *recv_info, const uint8_t *incomingData, int len){
  
  memcpy(&statusIn, incomingData, sizeof(statusIn));

  newData = true;

  lastValidSignal = millis();
}

void setupComms(const uint8_t remoteAddress[6]){
  WiFi.begin();
  WiFi.mode(WIFI_MODE_STA);
  Serial.println("Mac Address:" + WiFi.macAddress()); //Goodmorning Birmingham
  esp_now_init();
  
  memcpy(peerInfo.peer_addr, remoteAddress, 6);
  peerInfo.channel = 0; 
  peerInfo.encrypt = false;

  esp_now_register_recv_cb(getTransmittedData);

  esp_now_add_peer(&peerInfo);
}

void sendData(const cycleCommand_t &commandOut, uint8_t remoteAddress[6]){
  esp_now_send(remoteAddress, (uint8_t *) &commandOut, sizeof(commandOut));
}