#include "Arduino.h"
#include "CommsRB.h"
#include <WiFi.h>
#include <esp_now.h>

cycleCommand_t commandIn;
droneStatus_t statusOut;
esp_now_peer_info_t peerInfo;
unsigned long lastValidSignal;

void getTransmittedData(const esp_now_recv_info_t *recv_info, const uint8_t *incomingData, int len){  
  memcpy(&commandIn, incomingData, sizeof(commandIn));

  lastValidSignal = millis();
}

void setupComms(const uint8_t remoteAddress[6]){
  WiFi.begin();
  WiFi.mode(WIFI_MODE_STA);
  Serial.println("Mac Address:" + WiFi.macAddress()); //Goodmorning Birmingham
  esp_now_init();
  
  memcpy(peerInfo.peer_addr, remoteAddress, 6);
  peerInfo.channel = 0; 
  peerInfo.encrypt = false;

  esp_now_register_recv_cb(getTransmittedData);

  esp_now_add_peer(&peerInfo);
}

void sendData(const droneStatus_t &dataOut, uint8_t remoteAddress[6]){
  esp_now_send(remoteAddress, (uint8_t *) &dataOut, sizeof(dataOut));
}