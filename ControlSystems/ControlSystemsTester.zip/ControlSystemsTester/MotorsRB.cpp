#include "Arduino.h"
#include "MotorsRB.h"

int escRate = 50;
int minThrottle = 20;

Motor::Motor(int pinIn) {
  ledcAttach(pinIn, escRate, 10);
  myPin = pinIn;
}

int Motor::thrustToDuty(float thrust) {
  int duty;
  float maxDuty = int(1024 * (0.002 * escRate));
  float minDuty = int(1024 * (0.001 * escRate));
  duty = int(minDuty + (maxDuty - minDuty) * (thrust / 100));
  return duty;
}

void Motor::setThrust(float thrust) {
  thrustOut = thrust;
  ledcWrite(myPin, thrustToDuty(thrust));
}

void Motor::disarm() {
  ledcWrite(myPin, 0);
}

X4XONLY::X4XONLY() : fl(7), bl(8), fr(9), br(10) {} 

void X4XONLY::setTorqueX(float _torque){
  float torque = constrain(_torque, -12.5, 12.5);
  if (torque>0){
    fl.setThrust(minThrottle);
    fr.setThrust(minThrottle+torque);
    br.setThrust(minThrottle+torque);
    bl.setThrust(minThrottle);
  }
  else{
    fl.setThrust(minThrottle-torque);
    fr.setThrust(minThrottle);
    br.setThrust(minThrottle);
    bl.setThrust(minThrottle-torque);
  }
}

void X4XONLY::armMotors(){
  fl.setThrust(0);
  fr.setThrust(0);
  br.setThrust(0);
  bl.setThrust(0);
  delay(2500);
}

void X4XONLY::disarmMotors(){
  fl.disarm();
  fr.disarm();
  br.disarm();
  bl.disarm();
}

