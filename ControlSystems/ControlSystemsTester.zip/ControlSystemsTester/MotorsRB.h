#ifndef MotorsRB_h
#define MotorsRB_h
#include <Arduino.h>

class Motor {
private:
  float thrustOut;
  float adjustment;
  int myPin;
public:
  Motor(int pinIn);

  int thrustToDuty(float thrust);

  void setThrust(float thrust);

  void disarm();
};

class X4XONLY {
private:
  Motor fl;
  Motor bl;
  Motor fr;
  Motor br;

public:
  X4XONLY();
  void setTorqueX(float torque);
  void armMotors();
  void disarmMotors();
};

#endif