#pragma once

#include "Arduino.h"
#include <WiFi.h>
#include <esp_now.h>

typedef struct cycleCommand_t {
  float P;
  float I;
  float D;
  float I_MAX;
  float cycles;
  uint8_t estop;
} cycleCommand_t;

typedef struct droneStatus_t {
  float P;
  float I;
  float D;
  float angle;
  float time;
} droneStatus_t;

extern cycleCommand_t commandIn;
extern droneStatus_t statusOut;
extern esp_now_peer_info_t peerInfo;
extern unsigned long lastValidSignal;

void getTransmittedData(const esp_now_recv_info_t *recv_info, const uint8_t *incomingData, int len);
void setupComms(const uint8_t remoteAddress[6]);
void sendData(const droneStatus_t &dataOut, uint8_t remoteAddress[6]);